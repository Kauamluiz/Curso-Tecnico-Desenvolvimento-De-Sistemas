[![Arduino Library CI](https://github.com/cyijun/ESP32MQTTClient/actions/workflows/arduinoci.yml/badge.svg)](https://github.com/cyijun/ESP32MQTTClient/actions/workflows/arduinoci.yml)

# ESP32MQTTClient
A thread safe MQTT client for Arduino ESP32xx
